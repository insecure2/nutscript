
## Introduction
NutScript 1.1 is the re-working of the original NutScript framework to provide a better back-end. This should include more efficient code and overall benefits to the way the framework functioned and/or performed.

## Documentation
Check out the Nutscript wiki at https://nutscript.miraheze.org/wiki/Main_Page

## Got more questions?
Get on Official Discord https://discord.gg/QUbmYuD and meet the developers of Nutscript!

In other option you can go Gitters! https://gitter.im/Chessnut/NutScript

Maybe you can join the forum! https://nutscript.net (recommended)

