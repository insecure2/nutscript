ATTRIBUTE.name = "Endurance"
ATTRIBUTE.desc = "Affects how long you can run for."